/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();
    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter)
        regexp = new RegExp(seriesFilter, 'i');

    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 24.666666666666668, "KoPercent": 75.33333333333333};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
			"color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.004571428571428572, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [0.008, 500, 1500, "RetrieveCustomerID"], "isController": false}, {"data": [0.0, 500, 1500, "LogintoACE"], "isController": false}, {"data": [0.008, 500, 1500, "RetrieveCustomer"], "isController": false}, {"data": [0.008, 500, 1500, "SearchCustomer"], "isController": false}, {"data": [0.008, 500, 1500, "CheckVelocity"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller"], "isController": true}, {"data": [0.0, 500, 1500, "UpdateVelocity"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 750, 565, 75.33333333333333, 14902.936000000005, 60698.0, 60935.299999999996, 61300.98, 1.3740995067898836, 1.6806721997455167, 1.0165742021749247, 672, 61639], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average response time", "90th pct", "95th pct", "99th pct", "Throughput", "Received KB/sec", "Sent KB/sec", "Min", "Max"], "items": [{"data": ["RetrieveCustomerID", 125, 96, 76.8, 15326.527999999995, 60701.6, 61108.1, 61464.06, 0.23603565837898263, 0.2798165849511217, 0.0778364464076317, 1034, 61521], "isController": false}, {"data": ["LogintoACE", 125, 76, 60.8, 14511.943999999992, 60558.2, 60786.5, 61123.32, 0.23150077321258253, 0.2706352554842533, 0.11404306840384847, 1017, 61128], "isController": false}, {"data": ["RetrieveCustomer", 125, 93, 74.4, 13308.023999999998, 60887.0, 61115.2, 61535.74, 0.23480351641746186, 0.36855163505428656, 0.08298836783379668, 991, 61536], "isController": false}, {"data": ["SearchCustomer", 125, 94, 75.2, 18812.551999999996, 60736.4, 60813.8, 61550.86, 0.23200004454400858, 0.30603162125807126, 0.09609514345026754, 672, 61639], "isController": false}, {"data": ["CheckVelocity", 125, 96, 76.8, 11555.672000000008, 60656.6, 60966.2, 61136.02, 0.23735604355958112, 0.24885483126358865, 0.43436341405812373, 1038, 61142], "isController": false}, {"data": ["Transaction Controller", 125, 110, 88.0, 89427.65600000005, 245802.2, 275932.7999999999, 303114.39999999997, 0.2289905729160942, 1.6804813101329243, 1.0164587403640766, 6380, 304248], "isController": true}, {"data": ["UpdateVelocity", 125, 110, 88.0, 15902.896, 60666.4, 60814.4, 61352.04, 0.23738714615071996, 0.24853321449732796, 0.24185670101183895, 1044, 61416], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Percentile 1
            case 5:
            // Percentile 2
            case 6:
            // Percentile 3
            case 7:
            // Throughput
            case 8:
            // Kbytes/s
            case 9:
            // Sent Kbytes/s
            case 10:
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0);
    
    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 16, 2.831858407079646, 2.1333333333333333], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 101, 17.876106194690266, 13.466666666666667], "isController": false}, {"data": ["404/Not Found", 448, 79.29203539823008, 59.733333333333334], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);
    
        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 750, 565, "404/Not Found", 448, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 101, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 16, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["RetrieveCustomerID", 125, 96, "404/Not Found", 76, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 20, null, null, null, null, null, null], "isController": false}, {"data": ["LogintoACE", 125, 76, "404/Not Found", 63, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 9, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 4, null, null, null, null], "isController": false}, {"data": ["RetrieveCustomer", 125, 93, "404/Not Found", 72, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 16, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 5, null, null, null, null], "isController": false}, {"data": ["SearchCustomer", 125, 94, "404/Not Found", 67, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 23, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 4, null, null, null, null], "isController": false}, {"data": ["CheckVelocity", 125, 96, "404/Not Found", 80, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 13, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 3, null, null, null, null], "isController": false}, {"data": [], "isController": true}, {"data": ["UpdateVelocity", 125, 110, "404/Not Found", 90, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: aceapi.uaeexchange.com:443 failed to respond", 20, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);
    
});
